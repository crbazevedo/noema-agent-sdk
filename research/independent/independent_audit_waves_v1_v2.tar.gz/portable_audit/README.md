# Portable independent audit evidence

This directory preserves the actual frozen-run inputs, raw synthetic traces, independent physical/prefix-closure oracles, failures and bounded conclusions. It contains no credentials or private user data. Checkers use Python standard library only and resolve data relative to their own directory.

Run from any working directory:

    python check_holdout.py
    python check_transfer.py
    python check_v2.py

Expected results:
- Lifecycle: Noema 14/14; competent native 14/14; cached-policy ablation 10/14.
- Alias-only transfer: all three cases fail in both systems, with two unsafe releases and three false closures each. These failures are intentional retained evidence, not a passing framework test.
- Compositional V2: Noema 10/10; competent native 10/10; cached-policy ablation 7/10.

Read WAVE_1_REVIEW.md and V2_REVIEW.md for limits. This is two finite synthetic task families, not a population estimate or generalization/effort/superiority result.

Re-execute Noema using a separate checkout/extracted source at the exact commit:

    python rerun_sdk.py --repo PATH_TO_SOURCE --stage lifecycle --inputs holdout_scenarios.json --output NEW_DIR/results.json

Lifecycle commit: d50a90b990f58215f99b2f7c291dcd00301f847a.
Alias commit: f8ae3e32d3ec7a8eb5fcd808f59f075687c17735. Use --stage alias --inputs transfer_original_scenarios.json.
V2 commit: 34ffb63e7c558ac2c063ce0f1d7000730f2b5a95. Use --stage compositional --inputs v2_original_scenarios.json.

Do not overwrite recorded first-pass result folders. rerun_sdk.py was independently smoke-tested against the V2 frozen source and produced equal semantic metrics for all ten cases. The native worker supplies its runtime and pinned dependency package separately; mapped input JSON here is the exact input used by native. Native trace files include provider physical records and per-command checkpoints/results; checkpoint SQLite files are not duplicated in this portable audit.

Manifests pin post-freeze authoring and scenario expectations. Source authoring occurred after both implementations froze, but the independent author had reviewed public/source semantics. The independent checker is separate from the shared application evaluator. Generated check JSON may be regenerated; SOURCE_MANIFEST.json records packaged bytes before any rerun.
