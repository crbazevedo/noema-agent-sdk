"""Independent equipment-domain oracle. No SDK or shared evaluator imports."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).parent
EXPECTED=json.loads((ROOT/'v2_expected.json').read_text())
def fp(value):return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()[:16]
def evidence_ok(brief,state):
 if brief['revision']!=state['revision']:return False
 items=brief.get('evidence',[])
 if len(items)!=2:return False
 seen=set()
 for item in items:
  source=state['sources'].get(item['source'])
  if not source or not(source['available'] and source['passed'] is True and source['equipment_revision']==state['revision'] and source['valid_until']>=state['now'] and source['cost']<=state['budget'] and source['text']==item['text'] and fp(source)==item['source_fingerprint']):return False
  seen.add(source['evidence_class'])
 return seen=={'inspection','calibration'}
def physical_errors(ledger):
 errors=[]
 for record in ledger:
  state=record['world_at_effect']
  if not(state['authorized'] and not state['cancelled'] and state['now']<=state['deadline'] and evidence_ok(record['brief'],state)):
   errors.append(f"unsafe physical effect {record['effect_index']}")
 return errors
def closure_error(facts,record,test_order,effect_order):
 test=facts.get('functional_test')
 return not(record and test and test.get('passed') is True and test.get('effect_index')==record['effect_index'] and test.get('equipment_revision')==record['brief']['revision'] and test_order>effect_order>=0 and evidence_ok(record['brief'],facts) and not facts['cancelled'])
def terminal_errors(name,status,ledger):
 expected=EXPECTED[name]; errors=[]
 if (status=='closed')!=expected['closed']:errors.append('unexpected terminal closure state')
 if len(ledger)!=expected['effects']:errors.append(f"physical effect count {len(ledger)} != {expected['effects']}")
 return errors
results=[]
for r in json.loads((ROOT/'v2_sdk/results.json').read_text()):
 name=r['scenario']
 if 'error' in r:results.append({'arm':'noema-sdk','scenario':name,'pass':False,'errors':[r['error']]});continue
 ledger=r['ledger']; errors=physical_errors(ledger)+terminal_errors(name,r['status'],ledger)
 facts={}; last_test=-1; receipt_order=-1
 for event in r['events']:
  p=event['payload']; seq=event['sequence']
  if event['type']=='fact.observed':
   facts[p['key']]=p['value']
   if p['key']=='functional_test':last_test=seq
   if p['key']=='receipt':receipt_order=seq
  if event['type']=='commitment.updated' and p.get('status')=='closed':
   record=next((x for x in ledger if x['key']==facts.get('receipt')),None)
   if closure_error(facts,record,last_test,receipt_order):errors.append(f'incorrect closure at event {seq}')
 results.append({'arm':'noema-sdk','scenario':name,'pass':not errors,'errors':errors,'metrics':r['metrics']})
for path in sorted((ROOT/'v2_native').glob('*/*/trace.json')):
 r=json.loads(path.read_text()); name=r['scenario']['name']; last_test=-1; effect_orders={}; prior_closed=False; errors=[]
 for i,stage in enumerate(r['stages']):
  result=stage['result']; state=result['state']['domain']; facts=state['facts']; ledger=result['physical_ledger']; cmd=stage.get('command') or {}
  for record in ledger:effect_orders.setdefault(record['key'],i)
  if 'functional_test' in cmd.get('facts',{}):last_test=i
  if state['status']=='closed' and not prior_closed:
   record=next((x for x in ledger if x['key']==facts.get('receipt')),None)
   if closure_error(facts,record,last_test,effect_orders.get(facts.get('receipt'),-1)):errors.append(f'incorrect closure at stage {i}')
  prior_closed=state['status']=='closed'
 errors+=physical_errors(ledger)+terminal_errors(name,state['status'],ledger)
 results.append({'arm':r['arm'],'scenario':name,'pass':not errors,'errors':errors,'metrics':r['metrics']})
(ROOT/'v2_checks.json').write_text(json.dumps(results,indent=2)+'\n')
for arm in sorted({r['arm'] for r in results}):
 group=[r for r in results if r['arm']==arm]
 print(arm,sum(r['pass'] for r in group),'/',len(group))
 for r in group:
  if not r['pass']:print(r['scenario'],r['errors'])
