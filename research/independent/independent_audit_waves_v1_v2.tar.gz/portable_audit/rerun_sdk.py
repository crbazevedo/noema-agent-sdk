"""Portable replay helper; use the exact frozen source checkout for the selected stage."""
import argparse,asyncio,importlib,json,sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--stage',choices=['lifecycle','alias','compositional'],required=True)
p.add_argument('--inputs',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
args=p.parse_args()
sys.path[:0]=[str(args.repo.resolve()/'examples'),str(args.repo.resolve()/'src')]
from commitment_lifecycle import run_scenario
from commitment_lifecycle_domain import Scenario
async def main():
 cases=json.loads(args.inputs.read_text())
 if args.stage!='lifecycle':
  from declarative_transfer import map_scenario
  filename='equipment_mapping_v2.json' if args.stage=='compositional' else 'equipment_mapping.json'
  mapping=json.loads((args.repo/'research/declarative_transfer'/filename).read_text())
  scenarios=[map_scenario(c,mapping) for c in cases]
 else:scenarios=[Scenario(**c) for c in cases]
 kwargs={}
 if args.stage=='compositional':kwargs['domain_module']=importlib.import_module('compositional_lifecycle_domain')
 args.output.parent.mkdir(parents=True,exist_ok=True)
 results=[]
 for case in scenarios:
  try:result=await run_scenario(case,artifact_dir=args.output.parent,**kwargs)
  except Exception as error:result={'scenario':case.name,'error':repr(error)}
  results.append(result)
  args.output.write_text(json.dumps(results,indent=2)+'\n')
 print(f'Wrote {len(results)} complete/error results to {args.output}')
asyncio.run(main())
