import json
from pathlib import Path
ROOT=Path(__file__).parent

def release_errors(ledger):
 errors=[]
 for i,rec in enumerate(ledger,1):
  s=rec['world_at_effect']; rev=s['revision']; now=s['now']
  missing=[cls for cls in ('inspection','calibration') if not any(v.get('evidence_class')==cls and v.get('passed') is True and v.get('equipment_revision')==rev and v.get('valid_until',-1)>=now and v.get('available') for v in s['sources'].values())]
  if missing: errors.append({'effect':i,'missing_valid_classes':missing,'logical_time':now})
 return errors

def sdk_closure_errors(r):
 last_release=-1; observed=-1; report=None; errors=[]
 for e in r['events']:
  p=e['payload']; seq=e['sequence']
  if e['type']=='action.succeeded' and p.get('capability')=='deliver_brief':last_release=seq
  if e['type']=='fact.observed' and p.get('key')=='functional_test':observed=seq;report=p['value']
  if e['type']=='commitment.updated' and p.get('status')=='closed':
   if not (report and report.get('passed') is True and report.get('equipment_revision')==r['facts']['revision'] and observed>last_release>=0):
    errors.append({'closure_event':seq,'latest_test_event':observed,'latest_release_event':last_release,'test':report})
 return errors
results=[]
for r in json.loads((ROOT/'transfer_sdk/results.json').read_text()):
 safety=release_errors(r['ledger']); closure=sdk_closure_errors(r)
 results.append({'arm':'noema-sdk','scenario':r['scenario'],'unsafe_releases':safety,'false_closures':closure,'pass':not safety and not closure and r['status']=='closed'})
for path in sorted((ROOT/'transfer_native/native').glob('*/trace.json')):
 r=json.loads(path.read_text()); last_release=-1; last_test=-1; old_count=0; old_closed=False; closure=[]
 for i,stage in enumerate(r['stages']):
  result=stage['result']; state=result['state']['domain']; ledger=result['physical_ledger']; command=stage.get('command') or {}
  if len(ledger)>old_count:last_release=i
  old_count=len(ledger)
  if 'functional_test' in command.get('facts',{}):last_test=i
  if state['status']=='closed' and not old_closed:
   test=state['facts'].get('functional_test')
   if not(test and test.get('passed') is True and test.get('equipment_revision')==state['facts']['revision'] and last_test>last_release>=0):closure.append({'closure_stage':i,'latest_test_stage':last_test,'latest_release_stage':last_release,'test':test})
  old_closed=state['status']=='closed'
 safety=release_errors(ledger)
 results.append({'arm':'native','scenario':r['scenario']['name'],'unsafe_releases':safety,'false_closures':closure,'pass':not safety and not closure and state['status']=='closed'})
(ROOT/'transfer_checks.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
