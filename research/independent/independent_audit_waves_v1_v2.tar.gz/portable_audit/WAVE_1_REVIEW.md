# Independent review: measured commitment lifecycle

## Result
Frozen SDK d50a90b990f58215f99b2f7c291dcd00301f847a and competent native LangGraph both passed all 14 newly authored finite synthetic cases: 11 positive outcomes and three correct non-completions. Both made 49 tool calls and 14 physical delivery effects (three positive cases require two deliveries). No unsafe effects, false closure, missed positives, wrong final content or excess delivery invocations were found. Cached-policy native ablation passed 10/14 and caused four unsafe effects. This establishes parity in this one synthetic task family, not superiority, field utility, human effort saving or broad transfer.

## Evidence and procedure
Both implementations and domain were frozen before case authorship. HOLDOUT_MANIFEST.json pins scenarios and expected results. Author was separate from implementers but had reviewed source and public tests; this is not source-blind authorship. No source changes were permitted during results. An independently implemented physical-record checker verifies source content/revision, authority, cancellation, availability, feasibility ceiling, deadline and expected closure/effect counts. Raw SDK events and native checkpoints/traces are preserved. holdout_checks.json contains every result, including ablation failures.

Full local aggregate: 230 tests, 224 passed, six PostgreSQL-dependent skips; Ruff, strict mypy (86 files), compileall and sdist/wheel build passed. Diff-check clean. No runtime core files changed in Wave B. Remote publication is not cleared by this local review and requires parent authorization and exact-head remote/CI verification.

## Corrections during development
Review caught closure accepting obsolete receipts, missing budget enforcement, a structurally vacuous duplicate-effects metric, hypothetical content-change wording when only revision changed, partial failure evidence loss, and unlike cognition/timing accounting boundaries. Developer corrected contracts and preserved earlier development outputs. These were pre-freeze corrections, not withheld failures.

## Limits
The controller is hand-authored deterministic application logic. The full application loop uses actual SDK components, but does not exercise every SDK subsystem. Noema restarts are orderly same-process reconstruction; native launches a fresh process for every command. Those unmatched schedules preclude causal timing comparisons. Logical timer facts do not test durable real-time scheduling. The provider owns physical deduplication. Policy is local pre-invocation, not atomic authorization at a real remote effect. Cognition callback counts differ in whether terminal no-op wakes count. Only one task family was tested; case count is not independent domain count. No models, paid APIs or private data were used.

## Transfer counterexample
A subsequently frozen alias-only equipment mapping f8ae3e32d3ec7a8eb5fcd808f59f075687c17735 retained the single-source controller. Three independently authored cases all fail the equipment-domain oracle in both runtimes: calibration failed/expired on two releases; all three close before valid independent functional confirmation. The old briefing oracle reports success because it lacks these new obligations. transfer_checks.json preserves concrete release and closure evidence.

This is an expected representability limit of the constrained application contract, not a limitation of either framework or a comparison against an unrestricted competent domain controller. Missing reusable semantics are conjunction of independently valid evidence classes and causally later effect-bound postconditions. Any repair is a new version; exposed cases become regressions and fresh holdouts are required.
