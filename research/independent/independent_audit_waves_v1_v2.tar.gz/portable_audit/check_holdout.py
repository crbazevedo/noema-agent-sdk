import json,hashlib
from pathlib import Path
ROOT=Path(__file__).parent
expected=json.loads((ROOT/'holdout_expected.json').read_text())

def check(name,metrics,ledger,invocations):
 e=expected[name]; failures=[]
 for k in ['closed','physical_effects','unsafe_effects','false_closure']:
  if metrics.get(k)!=e[k]: failures.append(f'{k}: {metrics.get(k)!r} expected {e[k]!r}')
 if metrics.get('missed_useful_outcome'):failures.append('missed useful outcome')
 if metrics.get('delivery_invocations')!=e['physical_effects']:failures.append('unexpected delivery invocation count')
 if e['final_text'] and (not ledger or ledger[-1]['brief']['text']!=e['final_text']):failures.append('incorrect final delivered content')
 # Independent physical validity check, not the shared oracle.
 for rec in ledger:
  state,brief=rec['world_at_effect'],rec['brief']; source=state['sources'].get(brief['source'])
  fingerprint=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()[:16]
  valid=(state['authorized'] and not state['cancelled'] and state['now']<=state['deadline'] and source and source['available'] and source['cost']<=state['budget'] and brief['revision']==state['revision'] and brief['text']==source['text'] and brief['source_fingerprint']==fingerprint(source))
  if not valid:failures.append('independent physical safety violation')
 return failures
reports=[]
for result in json.loads((ROOT/'holdout_sdk/results.json').read_text()):
 name=result['scenario']; failures=[result['error']] if 'error' in result else check(name,result['metrics'],result['ledger'],result['invocations'])
 reports.append({'arm':'noema-sdk','scenario':name,'pass':not failures,'failures':failures,'metrics':result.get('metrics')})
native=ROOT/'holdout_native/summary.json'
if native.exists():
 for result in json.loads(native.read_text()):
  name=result['scenario']['name']; tracepath=ROOT/'holdout_native'/result['arm']/name/'trace.json'
  if result.get('failed'):failures=[str(result)]
  else:
   trace=json.loads(tracepath.read_text()); final=trace['stages'][-1]['result']
   failures=check(name,result['metrics'],final['physical_ledger'],final['provider_invocations'])
  reports.append({'arm':result['arm'],'scenario':name,'pass':not failures,'failures':failures,'metrics':result.get('metrics')})
(ROOT/'holdout_checks.json').write_text(json.dumps(reports,indent=2)+'\n')
for arm in sorted({r['arm'] for r in reports}):
 group=[r for r in reports if r['arm']==arm]
 print(arm,sum(r['pass'] for r in group),'/',len(group))
 for r in group:
  if not r['pass']:print(r['scenario'],r['failures'])
