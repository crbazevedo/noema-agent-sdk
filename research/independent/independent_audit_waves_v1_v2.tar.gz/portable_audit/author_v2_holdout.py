import json,hashlib
from pathlib import Path
ROOT=Path(__file__).parent
w={'op':'wake'};r={'op':'restart'}
def u(**f):return {'op':'update','facts':f}
def b(**f):return {'op':'wake','before_effect':f}
def ev(cls,revision=6,verdict=True,until=20,cost=1,text=None):return {'available':True,'cost':cost,'text':text or f'{cls}-r{revision}-{verdict}-{until}','evidence_class':cls,'passed':verdict,'equipment_revision':revision,'valid_until':until}
def src(revision=6,iv=True,cv=True,ce=20,tag=''):
 return {'i':ev('inspection',revision,iv,cost=1,text='I'+tag),'c':ev('calibration',revision,cv,until=ce,cost=2,text='C'+tag)}
def start(source=None,test=None):return u(equipment_revision=6,release_authorized=True,withdrawn=False,evidence_sources=source if source is not None else src(),max_source_cost=3,logical_time=1,release_deadline=12,release_receipt_visible=True,functional_test=test)
def report(effect=1,revision=6,passed=True):return {'effect_index':effect,'equipment_revision':revision,'passed':passed}
cases=[]; expected={}
def add(name,commands,closed,effects,revision=6):
 cases.append({'name':name,'expected_revision':revision if closed else None,'commands':commands})
 expected[name]={'closed':closed,'effects':effects}
add('v201_preloaded_success_restart_then_real_observation',[start(test=report()),w,w,r,w,w,u(functional_test=report(),logical_time=2),w],True,1)
old=src();old['c']=ev('calibration',revision=5,cost=2)
add('v202_stale_class_revision_later_repaired',[start(old),w,r,w,u(evidence_sources=src(tag='corrected'),logical_time=2),w,w,u(functional_test=report(revision=5)),w,u(functional_test=report()),w],True,1)
add('v203_newest_failed_test_blocks_until_repaired',[start(),w,w,u(functional_test=report()),u(functional_test=report(passed=False)),r,w,u(functional_test=report()),w],True,1)
add('v204_delayed_old_effect_same_revision',[start(),w,w,u(evidence_sources=src(tag='new-cycle'),logical_time=2),w,w,u(functional_test=report(effect=1)),r,w,u(functional_test=report(effect=2)),w],True,2)
add('v205_authority_revoked_then_restored',[start(),w,b(release_authorized=False),r,w,u(release_authorized=True),w,u(functional_test=report()),w],True,1)
add('v206_conjunct_expiry_then_new_source',[start(src(ce=1)),w,b(logical_time=2),w,u(evidence_sources=src(tag='renewed'),logical_time=3),w,w,u(functional_test=report()),w],True,1)
add('v207_old_revision_report_never_completes',[start(),w,w,u(functional_test=report(revision=5)),r,w,w],False,1)
missing={'i':ev('inspection')}
add('v208_missing_class_never_released',[start(missing),w,w,r,w],False,0)
add('v209_cancel_before_effect_despite_valid_sources',[start(),w,b(withdrawn=True),u(functional_test=report()),r,w],False,0)
add('v210_wait_receipt_and_report_at_deadline',[start(),w,w,u(release_receipt_visible=False,functional_test=report(passed=False)),w,r,u(release_receipt_visible=True,functional_test=report(),logical_time=12),w],True,1)
(ROOT/'v2_original_scenarios.json').write_text(json.dumps(cases,indent=2)+'\n')
(ROOT/'v2_expected.json').write_text(json.dumps(expected,indent=2)+'\n')
manifest={'sdk_commit':'34ffb63e7c558ac2c063ce0f1d7000730f2b5a95','native_freeze':'2026-10-12T16:31:10.291838Z','authored_after_both_freezes':True,'cases':10,'positives':7,'negatives':3,'family':'equipment conjunctive evidence and effect-bound observation','predeclared_checks':['zero unsafe release','zero premature/incorrect closure at any prefix','expected effect counts and terminal closure','current conjunctive evidence at each effect','latest effect/revision-specific report arrived after exact effect before closure'],'files':{}}
for file in ['v2_original_scenarios.json','v2_expected.json','author_v2_holdout.py']:
 manifest['files'][file]=hashlib.sha256((ROOT/file).read_bytes()).hexdigest()
(ROOT/'V2_HOLDOUT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
