from pathlib import Path
import json, hashlib
out=Path(__file__).parent
w={'op':'wake'}; r={'op':'restart'}
def u(**f):return {'op':'update','facts':f}
def src(text,cost=2,available=True,name='primary'):return {name:{'text':text,'cost':cost,'available':available}}
def b(**f):return {'op':'wake','before_effect':f}
cases=[]; expected={}
def add(name,commands,closed,effects,text=None,revision=1):
 cases.append({'name':name,'commands':commands,'expected_revision':revision if closed else None})
 expected[name]={'closed':closed,'physical_effects':effects,'final_text':text,'unsafe_effects':0,'false_closure':False}
add('h01_same_revision_content_replaced',[w,u(sources=src('H01 new observation')),u(authorized=True),w,w,w],True,1,'H01 new observation')
add('h02_content_changes_after_delivery',[w,u(authorized=True),w,u(sources=src('H02 superseding observation')),w,w,w],True,2,'H02 superseding observation')
add('h03_changed_during_receipt_read',[w,u(authorized=True),w,b(sources=src('H03 concurrent correction')),w,w,w],True,2,'H03 concurrent correction')
add('h04_source_lost_then_backup',[w,u(authorized=True),b(sources=src('Lost',available=False)),u(sources=src('H04 backup',cost=1,name='secondary')),w,w,w],True,1,'H04 backup')
add('h05_ceiling_tightened_then_cheaper',[w,u(authorized=True),b(budget=1),u(sources=src('H05 low cost',cost=1)),w,w,w],True,1,'H05 low cost')
add('h06_expired_at_delivery',[w,u(authorized=True,now=9),b(now=11),w,r,w],False,0)
add('h07_deadline_extension_preserves_opportunity',[u(now=11),w,u(deadline=15),w,u(authorized=True),w,w],True,1,'Evidence A')
add('h08_revocation_after_valid_effect',[w,u(authorized=True),w,u(authorized=False),r,w,w],True,1,'Evidence A')
add('h09_silence_never_grants_permission',[w,w,r,w,w,w],False,0)
add('h10_empty_sources_later_arrival',[u(sources={}),w,w,r,u(sources=src('H10 new opportunity',cost=0,name='new')),w,u(authorized=True),w,w],True,1,'H10 new opportunity')
add('h11_revised_goal_after_delivery_restart',[w,u(authorized=True),w,u(revision=8,sources=src('H11 changed goal evidence')),r,w,w,r,w],True,2,'H11 changed goal evidence',revision=8)
add('h12_cancel_between_plan_and_delivery',[w,u(authorized=True),b(cancelled=True),r,w],False,0)
add('h13_invisible_receipt_repeated_wakes',[w,u(authorized=True,receipt_visible=False),w,w,r,w,w,u(receipt_visible=True),w,w],True,1,'Evidence A')
add('h14_exact_deadline_delivery_and_verification',[w,u(authorized=True,now=10),w,w],True,1,'Evidence A')
(out/'holdout_scenarios.json').write_text(json.dumps(cases,indent=2)+'\n')
(out/'holdout_expected.json').write_text(json.dumps(expected,indent=2)+'\n')
manifest={'authored_after_freeze':True,'noema_commit':'d50a90b990f58215f99b2f7c291dcd00301f847a','native_freeze':'2026-10-12T16:21:52.510042Z','scope':'14 independently authored finite synthetic conformance cases, one domain family; no population or superiority inference','case_author_exposure':'Reviewed shared domain, both orchestration adapters and public tests; not implementation author. Cases authored only after both freeze notices. No outcomes inspected before this manifest.','predeclared_checks':['all expected closure and effect counts','zero unsafe effects and false closure','final delivered content on every positive','no missed useful positive','delivery invocation count equals effect count for these no-retry cases'],'files':{}}
for name in ['holdout_scenarios.json','holdout_expected.json','author_holdout.py']:
 manifest['files'][name]=hashlib.sha256((out/name).read_bytes()).hexdigest()
(out/'HOLDOUT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
