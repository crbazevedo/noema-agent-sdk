import json,hashlib
from pathlib import Path
ROOT=Path(__file__).parent
w={'op':'wake'}
def update(**facts):return {'op':'update','facts':facts}
def evidence(cls,passed=True,until=20,cost=1):return {'available':True,'cost':cost,'text':f'{cls} result {passed}', 'evidence_class':cls,'passed':passed,'equipment_revision':4,'valid_until':until}
def sources(inspection=True,calibration=True,expiry=20):return {'inspection':evidence('inspection',inspection,cost=1),'calibration':evidence('calibration',calibration,until=expiry,cost=2)}
def initial(src):return update(equipment_revision=4,release_authorized=True,withdrawn=False,evidence_sources=src,max_source_cost=3,logical_time=1,release_deadline=10,release_receipt_visible=True,functional_test=None)
cases=[
 {'name':'t01_missing_calibration_later_passes','expected_revision':4,'commands':[initial(sources(calibration=False)),w,w,w,update(evidence_sources=sources(),logical_time=2),w,w,update(functional_test={'passed':True,'equipment_revision':4},logical_time=3),w]},
 {'name':'t02_other_class_expires_at_release','expected_revision':4,'commands':[initial(sources(expiry=1)),w,{'op':'wake','before_effect':{'logical_time':2}},w,update(evidence_sources=sources(),logical_time=3),w,w,update(functional_test={'passed':True,'equipment_revision':4},logical_time=4),w]},
 {'name':'t03_failed_functional_test_must_not_close','expected_revision':4,'commands':[initial(sources()),w,w,update(functional_test={'passed':False,'equipment_revision':4},logical_time=2),w,update(functional_test={'passed':True,'equipment_revision':4},logical_time=3),w]},
]
(ROOT/'transfer_original_scenarios.json').write_text(json.dumps(cases,indent=2)+'\n')
manifest={'frozen_mapping_commit':'f8ae3e32d3ec7a8eb5fcd808f59f075687c17735','authored_after_freeze':True,'domain':'equipment return-to-service','positive_cases':3,'predeclared_requirements':['each physical release needs current unexpired passing inspection AND calibration','no closure until independent passing equipment-specific functional test observed strictly after release','all three scenarios eventually safely fulfill'],'scope':'Constrained alias-only representability challenge over inherited single-source controller; not test of unrestricted competent native domain policy','files':{}}
for file in ['transfer_original_scenarios.json','author_transfer_holdout.py']:
 manifest['files'][file]=hashlib.sha256((ROOT/file).read_bytes()).hexdigest()
(ROOT/'TRANSFER_HOLDOUT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
