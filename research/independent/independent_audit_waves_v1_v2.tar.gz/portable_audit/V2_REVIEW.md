# Independent review: compositional evidence repair V2

Frozen SDK commit: 34ffb63e7c558ac2c063ce0f1d7000730f2b5a95.
Native freeze: 2026-10-12T16:31:10.291838Z.

## Result
Ten newly authored cases after both freezes: seven positive outcomes and three correct incomplete outcomes. Actual Noema and competent native LangGraph both pass 10/10, with 35 tool calls and nine physical effects each. Independent oracle finds zero unsafe releases, premature closures or missed positive outcomes. Cached-policy ablation passes 7/10, causes three unsafe effects and misses two positive outcomes. The two competent arms retain equal domain information and identical shared procedural semantics; parity is expected and observed.

Cases include a preloaded success report, delayed report for an earlier effect with the same revision, old source/test revisions, latest contradictory test, missing evidence class, authority revocation/restoration, a conjunct expiring between plan and effect, cancellation, provider visibility, orderly restart and exact logical-deadline completion. Independent physical and prefix-closure checks import no SDK or shared evaluator. Arrival ordering plus exact effect reference is tested; physical execution of a real functional test is not.

All frozen domain/adapter/config/native file hashes remain unchanged. Full exact local aggregate: 233 tests, 227 passed and six PostgreSQL-dependent skips; Ruff, mypy and compileall passed. Executable changes stay in examples, not canonical SDK runtime. Prior Wave B sdist/wheel build passed; no packaging configuration changed in V2.

## What improved, and what did not
The repair adds generic conjunctive evidence eligibility and effect-specific postcondition observation. Independent prefreeze review also caught an insufficient causal rule: later arrival plus matching revision cannot distinguish multiple effects at one revision. The final version adds exact provider-assigned effect ordinal and retains arrival ordering. Earlier alias-only failures remain preserved; exposed cases are development regressions, never counted as this new holdout.

V2 is a procedural repair. Relative to the alias-only freeze, it adds a 200-line, 7,661-byte shared domain module; changes the SDK example runner by 10 added/5 removed lines; adds 39 mapper/CLI lines and a 53-line, 1,484-byte declarative configuration; and adds 121 test lines. Counts describe artifact change surface, not engineering effort or ease. Both systems are charged for the same shared domain logic. The module name is selectable by either runtime; the native StateGraph controller is unchanged.

One equipment family and ten constructed cases do not establish open-domain transfer, learned causal understanding, general novelty, field effectiveness or human hours saved. The provider remains a synthetic effect ledger. A genuine new operational domain would need real capability/provider semantics, which must be counted separately from frozen-controller reuse. Unmatched process schedules and no-op cognition accounting still rule out causal performance/effort claims.

## Decision
No blocking engineering or claim-scope finding for the local tested V2 example within its declared contract. Publication is separately gated by the parent; no merge/deploy is authorized. Broader reuse remains an untested question, not a completed objective.
